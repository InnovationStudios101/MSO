class mso_ambience {
	class common {
		file = "ambience\functions\common";
		class failSafeLS {};
		class landForTime {};
	};
	class server {
		file = "ambience\functions\server";
		class spawnVehiclePath {};
		class dynocreate {};
	};
};
