class AEGheader {
        title = "    Ambient Power Grid"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};
class AEG_smokestack {
        title = "        Smokestack emissions"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
