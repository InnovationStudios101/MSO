Zargabad Poplulated Marketplace Template OA (Combined Operations)


I created a populated bazaar and medical outpost in downtown Zargabad with many placed models and some sounds for one of my upcoming missions "Vertigo." 

Maybe you are in need of populated marketplace.  


Also, add this script for some action:  


// Created by: kylania
// Based on code from SNKMAN
// http://forums.bistudio.com/showpost.php?p=1623731&postcount=4





