class AmbientEnvironment {
        title = "    Ambient - Environment"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class AmbientCivs {
        title = "        Enable Civilians"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
class AmbientVehs {
        title = "        Enable Civilian Vehicles"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
class AmbientAnimals {
        title = "        Enable Animals"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
