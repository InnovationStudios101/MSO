class destroyCity {
        title = "    Ambient - Destroy City"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class destroyCityIntensity {
        title = "        Enable Destroyed Cities"; 
        values[]= {0,1,2,3}; 
        texts[]= {"Off", "Low", "Med", "High"}; 
        default = 0;
};
class destroyCityFire {
        title = "        Enable Destroyed City Building Fires"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
