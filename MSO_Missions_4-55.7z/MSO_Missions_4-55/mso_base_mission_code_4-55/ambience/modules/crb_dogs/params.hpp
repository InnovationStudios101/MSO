class ambientDogs {
        title = "    Enable Wild Dogs"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};
