class AdminActions {
        title = "    Admin Actions"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class CFG_AdminCmds {
        title = "        Enable Admin Actions"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};
class CFG_AdminCmdTeleport {
        title = "        Enable Teleport"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};
class CFG_AdminCmdGhost {
        title = "        Enable Ghost"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};
class CFG_AdminCmdSpectator {
        title = "        Enable Spectator (ACE only)"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};