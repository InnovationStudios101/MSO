class MP_rights {
	file = "core\modules\rmm_MP_rights";
	class functions {
		class getRights {};
	};
};