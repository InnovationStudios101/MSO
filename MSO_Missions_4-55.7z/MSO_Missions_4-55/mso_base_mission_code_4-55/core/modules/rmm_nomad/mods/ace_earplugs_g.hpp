{player getVariable ["ace_sys_goggles_earplugs",false];},
