{player getVariable ["ACE_weapononback",""];},
{[player] call ACE_fnc_FindRuck;},
{[player] call ACE_fnc_RuckMagazinesList;},
{[player] call ACE_fnc_RuckWeaponsList;},
