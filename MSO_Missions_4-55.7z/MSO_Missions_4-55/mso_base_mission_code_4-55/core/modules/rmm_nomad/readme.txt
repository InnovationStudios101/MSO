Testing:
To test, move the NOMAD folder into MSOTesting.Zargabad\modules folder.

Launch using a dedicated server and perform the testing procedure before releasing:
- test player direction on reconnect
- test position in a vehicle on reconnect
- test type of weapons, number of magazines and backpack contents on reconnect
- test disconnect when returning as a different class
- test changing slot as same class

Wolffy - Successfully tested on dedi 09/OCT/10