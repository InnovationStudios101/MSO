class weather {
	file = "core\modules\rmm_weather";
	class functions {
		class forecast {};
		class sync {};
	};
};