class crb_convoy_intensity {
        title = "    Enemy Convoy Intensity"; 
        values[]= {0, 1, 2, 3}; 
        texts[]= {"None","Low","Med","High"}; 
        default = 0;
};

