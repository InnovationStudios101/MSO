// - Tested
#define MSOFACTIONS
#define CQB_POP
#define RMM_ENEMYPOP
#define ROY_PATROLOPS
#define RMM_ZORA
#define TUP_IED
#define CRB_CONVOYS

// - To Test
//#define WICT_ENEMYPOP
//#define RYD_HAC
//#define CRB_TERRORISTS
//#define BIS_WARFARE