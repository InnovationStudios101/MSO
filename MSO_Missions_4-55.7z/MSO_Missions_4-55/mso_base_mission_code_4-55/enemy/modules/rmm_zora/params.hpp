class ZORAmaxgrps {
        title = "    Simultaneous ZORA groups"; 
        values[]= {0,3,5}; 
        texts[]= {"Off","3","5"};
        default = 3;
};
class ZORAmindist {
        title = "        ZORA minimum spawndistance"; 
        values[]= {500,750,1000}; 
        texts[]= {"500m","750m","1000m"}; 
        default = 750;
};