class bis_som_header{
        title = "    BIS Secondary Operations Module"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};


