#include "script_settings.hpp"
	class MGO_Active {
		title = "    MGO Attach (ACE)";
		values[] = {0,1};
		default = 0;
		texts[] = {"Off","On"};
	};
	class MGO_SrvScript {
		title = "        MGO Extra Server Scripts:";
		values[] = {0,1};
		default = 0;
		texts[] = {"Not Configured","In Place"};
	};