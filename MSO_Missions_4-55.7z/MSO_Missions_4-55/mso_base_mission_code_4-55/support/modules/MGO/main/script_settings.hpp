//Enable systems
#define MGO_ATTACH_ENAB
