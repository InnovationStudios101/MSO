class R3F_REVIVEHEADER {
        title = "    R3F Revive"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};