class logistics {
	file = "support\modules\tup_logistics";
	class functions {
		class call {};
		class onload {};
		class delivery {};
		class findNonVehicleType {};
		class doDrop {};
		class doGPSDrop {};
		class doLift {};
		class bundleDelivery {};
		class deliverAircraft {};
		class createConvoy {};
		class createAirDelivery {};
		class addItemsR3F {};
		class spawnVehicle {};
		class validateOrder {};
		class formAddItem {};
		class formRemoveItem {};
		class formAddReplen {};
		class getCost;	
	};
};