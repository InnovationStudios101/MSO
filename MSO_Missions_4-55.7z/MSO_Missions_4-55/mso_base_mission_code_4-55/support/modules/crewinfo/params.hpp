class EnableCrewinfo {
        title = "    Enable Vehicle Crew Info"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};