// - Tested
//#define BIS_SOM
#define RMM_AAR
#define RMM_CAS
#define RMM_CASEVAC
#define RMM_CNSTRCT
#define CRB_TWNMGR
#define CRB_FLIPPABLE
#define RMM_JIPMARKERS
#define RMM_LOGBOOK
#define R3F_LOGISTICS
#define RMM_RECRUITMENT
#define RMM_REVIVE
#define R3F_REVIVE
#define RMM_TASKS
#define RMM_TYRES
#define WHB_MULTISPAWN
#define ZKS_Build
#define CREWINFO
#define MGO
#define PXS_SATCOM_OA
#define TUP_LOGISTICS

// WIP
//#define GC_PACK_COW
//#define TN_LHDELEVATOR

