Testing:
To test, move the module folder into MSOTesting.Zargabad\modules folder.

Modify the modules.hpp file and enable the module.

Launch using a dedicated server and perform the testing procedure before releasing:
- try creating 2 AAR entries of different texts
- try viewing each AAR entry in the Map Notes

Wolffy - testing working on dedi 4/NOV/10
