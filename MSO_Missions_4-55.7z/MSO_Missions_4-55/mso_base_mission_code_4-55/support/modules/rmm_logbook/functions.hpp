class logbook {
	file = "support\modules\rmm_logbook";
	class functions {
		class open {};
	};
};