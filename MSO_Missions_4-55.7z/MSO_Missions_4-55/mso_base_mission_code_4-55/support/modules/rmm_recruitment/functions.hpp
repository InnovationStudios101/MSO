class recruit {
	file = "support\modules\rmm_recruitment";
	class functions {
		class onload {};
	};
};