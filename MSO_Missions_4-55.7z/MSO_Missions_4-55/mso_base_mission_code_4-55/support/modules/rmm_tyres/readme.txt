Testing:
To test, move the TYRES folder into MSOTesting.Zargabad\modules folder.

Launch using a dedicated server and perform the testing procedure before releasing:
- test changing a tyre on the Jackal

Wolffy - tested on dedi 15/OCT/10