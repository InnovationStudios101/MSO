class crb_convoy_intensity {
        title = "    Enemy Convoy Intensity"; 
        values[]= {0, 1, 2, 3}; 
        texts[]= {"None","Low","Med","High"}; 
        default = 1;
};
class ConvoyLocality {
	title = "        Convoy Locality";
	values[]= {0,1}; 
	texts[]= {"Server","Headless Client"};
	default = 0;
};
