class reezo_eod_sound_akbar
{
	name = "reezo_eod_sound_akbar";
	sound[] = {"enemy\modules\tup_ied\sounds\reezo_eod_sound_akbar.ogg", db-18, 1.0};
	titles[] = {};
};