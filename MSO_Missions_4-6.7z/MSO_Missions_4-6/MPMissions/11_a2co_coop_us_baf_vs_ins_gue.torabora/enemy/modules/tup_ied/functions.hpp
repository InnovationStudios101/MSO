class tup_ied {
	file = "enemy\modules\tup_ied";
	class functions {
		class placeIED {};
	};
};