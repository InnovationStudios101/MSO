class AIMHeader {
        title = "    AIM Add-on (if available)"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class aim_descentratedrink {
        title = "        Drink Decent Rate"; 
  			values[]= {0,1,2,3,4,5}; 
        texts[]= {"off","very slow","slow","medium","fast","very fast"}; 
        default = 3;
};
class aim_descentratefood {
        title = "        Food Decent Rate"; 
  			values[]= {0,1,2,3,4,5}; 
        texts[]= {"off","very slow","slow","medium","fast","very fast"}; 
        default = 2;
};