[R3F] Revive : A lightweight and efficient revive
-------------------------------------------------
This software is the revive system for ArmA 2 and Operation Arrowhead, developed by the R3F (R�giment Force de Frappe Fran�aise, team-r3f.org).

You can get the full version of the [R3F] Revive (with the installation guide and the GPL license) here : http://forums.bistudio.com/showthread.php?t=92349

Feel free to give your feedback on the BIS topic : http://forums.bistudio.com/showthread.php?t=92349


	Copyright (C) 2011 madbull ~R3F~
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

Contact : team-r3f.org


[R3F] Revive : Un syst�me de r�animation l�ger et efficace
----------------------------------------------------------
Ce logiciel est le syst�me de r�animation pour ArmA 2 et Operation Arrowhead, mis au point par le R3F (R�giment Force de Frappe Fran�aise, team-r3f.org).

Vous pouvez obtenir la version compl�te du [R3F] Revive (avec le guide d'installation et la licence GPL) ici : http://forums.bistudio.com/showthread.php?t=92349

N'h�sitez pas � donner vos retours d'exp�riences sur le fil de discussion chez BIS : http://forums.bistudio.com/showthread.php?t=92349


	Copyright (C) 2011 madbull ~R3F~
	
	Ce programme est un logiciel libre ; vous pouvez le redistribuer ou le
	modifier suivant les termes de la "GNU General Public License" telle que
	publi�e par la Free Software Foundation : soit la version 3 de cette
	licence, soit (� votre gr�) toute version ult�rieure.
	
	Ce programme est distribu� dans l�espoir qu�il vous sera utile, mais SANS
	AUCUNE GARANTIE : sans m�me la garantie implicite de COMMERCIALISABILIT�
	ni d�AD�QUATION � UN OBJECTIF PARTICULIER. Consultez la Licence G�n�rale
	Publique GNU pour plus de d�tails.
	
	Vous devriez avoir re�u une copie de la Licence G�n�rale Publique GNU avec
	ce programme ; si ce n�est pas le cas, consultez :
	<http://www.gnu.org/licenses/>.

Contact : team-r3f.org