class TownManager {
        title = "    INTEL Reports (Towns)"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
class twnmgr_status {
        title = "        Update Map based on INTEL reports"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
class twnmgr_civ {
        title = "        Civilian HUMINT Reports"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
class twnmgr_detected {
        title = "        HUMINT Reports"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
class twnmgr_seized {
        title = "        SIGINT Reports"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};

class twnmgr_broadcastMP {
        title = "        Broadcast Reports to sideChat"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};