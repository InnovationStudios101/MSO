class EnablePXSsatcom {
        title = "    Enable PXS SATCOMs"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};