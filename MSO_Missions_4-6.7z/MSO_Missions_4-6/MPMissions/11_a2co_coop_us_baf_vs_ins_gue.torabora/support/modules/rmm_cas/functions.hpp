class cas {
	file = "support\modules\rmm_cas";
	class functions {
		class call {};
		class help {};
		class onload {};
	};
};