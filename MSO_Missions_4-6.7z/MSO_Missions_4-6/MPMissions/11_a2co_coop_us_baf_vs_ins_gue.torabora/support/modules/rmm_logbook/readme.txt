Testing:
To test, move the module folder into MSOTesting.Zargabad\modules folder.

Modify the modules.hpp file and enable the module.

Launch using a dedicated server and perform the testing procedure before releasing:
- try creating 2 logbook entries of different texts
- try viewing each logbook entry

Wolffy - confirmed working dedi server 4/NOV/10