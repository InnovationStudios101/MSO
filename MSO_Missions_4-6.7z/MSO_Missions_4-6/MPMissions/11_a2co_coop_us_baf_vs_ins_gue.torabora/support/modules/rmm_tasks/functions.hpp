class tasks {
        file = "support\modules\rmm_tasks";
        class functions {
                class add {};
                class click {};
                class deletenearest {};
                class taskadd {};
                class taskhint {};
                class taskupdate {};
				class onload {};
				class updatenearest {};
        };
};