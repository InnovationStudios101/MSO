class tyres {
	file = "support\modules\rmm_tyres";
	class functions {
		class change {};
	};
};