#define RMM_AAR
#define CRB_FLIPPABLE
#define RMM_JIPMARKERS
#define AIM

