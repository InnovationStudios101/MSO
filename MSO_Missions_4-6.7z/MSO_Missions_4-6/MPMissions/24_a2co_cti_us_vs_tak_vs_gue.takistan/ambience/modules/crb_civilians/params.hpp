class AmbientCivs {
        title = "    Ambient Civilians"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
class AmbientVehs {
        title = "        Enable Civilian Vehicles"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
class AmbientAnimals {
        title = "        Enable Animals"; 
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 1;
};
class AmbientLocality {
	title = "        Ambient Locality";
	values[]= {0,1}; 
	texts[]= {"Server","Headless Client"};
	default = 0;
};
