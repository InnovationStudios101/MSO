class dogs {
	file = "ambience\modules\crb_dogs";
	class functions {
		class blitzy {};
		class dogattack {};
		class wilddogs {};
	};
};