class ambientDogs {
        title = "    Enable Wild Dogs"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};
class DogsLocality {
	title = "        Wild Dogs Locality";
	values[]= {0,1}; 
	texts[]= {"Server","Headless Client"};
	default = 0;
};
