class Emergency {
        title = "    Enable Emergency Services"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};
class EmergencyLocality {
	title = "        Emergency Locality";
	values[]= {0,1}; 
	texts[]= {"Server","Headless Client"};
	default = 0;
};
