class ambientShepherds {
        title = "    Enable Shepherds"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};
class ShepherdsLocality {
	title = "        Shepherds Locality";
	values[]= {0,1}; 
	texts[]= {"Server","Headless Client"};
	default = 0;
};
