class cep {
	file = "core\modules\cep_cache";
	class functions {
		class cache {};
		class uncache {};
	};
};