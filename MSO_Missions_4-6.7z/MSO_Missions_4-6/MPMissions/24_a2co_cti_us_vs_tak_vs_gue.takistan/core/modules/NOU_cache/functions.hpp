class noujay {
	file = "core\modules\nou_cache";
	class functions {
		class sync {};
		class cache {};
		class uncache {};
	};
};