#define CRB_TIMESYNC
#define DRN_WEATHER
#define RMM_DEBUG
#define RMM_HELP
#define RMM_MP_RIGHTS
#define RMM_NOMAD
#define persistentDB
#define RMM_SETTINGS
#define RMM_WEATHER
#define RMM_GTK
#define NOU_CACHE
#define CEP_CACHE
#define VEHICLEIGNITIONKEYS
#define ADMINACTIONS

//#define RMM_OSOM
