class debug_serverfps {
	title = "    Debug - Server FPS to log"; 
	values[]= {0,30,60,180,300}; 
	texts[]= {"Off","30 sec", "1 min","3 min","5 min"}; 
	default = 0; 
};

class debug_mso_setting {
	title = "    Debug - Turn on Module Debugging"; 
	values[]= {0,1,2}; 
	texts[]= {"Off","On","include location markers"}; 
	default = 0; 
};

