class help {
	file = "core\modules\rmm_help";
	class functions {
		class display {};
		class onload {};
	};
};