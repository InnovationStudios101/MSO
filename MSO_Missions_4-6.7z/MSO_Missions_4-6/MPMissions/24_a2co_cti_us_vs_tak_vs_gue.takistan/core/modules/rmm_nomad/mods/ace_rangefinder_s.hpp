{EMP_RF_BAT = _this;},
