class settings_maxvd {
	title = "    Settings - Max ViewDistance"; 
	values[]= {10000,500,1000,1500,2000,2500,3000,3500,4000,4500,5000}; 
	texts[]= {"None","500","1000","1500","2000","2500","3000","3500","4000","4500","5000"}; 
	default = 10000;
};
