class VehicleActions {
        title = "    Vehicle Keys"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class CFG_VehicleIgnitionKeys {
        title = "        Enable Vehicle Ignition Keys";
        values[]= {0,1}; 
        texts[]= {"Off", "On"}; 
        default = 0;
};
