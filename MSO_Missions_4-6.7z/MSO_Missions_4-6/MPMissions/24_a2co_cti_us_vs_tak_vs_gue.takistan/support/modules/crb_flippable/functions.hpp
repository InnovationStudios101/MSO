class flippable {
	file = "support\modules\crb_flippable";
	class functions {
		class vehicleFlip {};
	};
};